package org.libertas;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.stream.Collectors;

import com.google.gson.Gson;

/**
 * Servlet implementation class PessoaAPI
 */
@WebServlet("/PessoaAPI/*")
public class PessoaAPI extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public PessoaAPI() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PessoaDao pdao = new PessoaDao();
        Gson gson = new Gson();

        int id = 0;
        try {
            id = Integer.parseInt(request.getPathInfo().substring(1));
        } catch (Exception e) {
            e.printStackTrace();
        }
        String resposta;
        if (id == 0) {
            resposta = gson.toJson(pdao.listar());
        } else {
            resposta = gson.toJson(pdao.consultar(id));
        }

        response.setHeader("Content-Type", "application/json");
        response.getWriter().print(resposta);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String body = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
        Gson gson = new Gson();
        Pessoa p = gson.fromJson(body, Pessoa.class);
        PessoaDao pdao = new PessoaDao();

        boolean sucesso = pdao.inserir(p);
        Retorno retorno = new Retorno(sucesso, sucesso ? "Inserido com sucesso" : "Erro ao inserir");

        response.setHeader("Content-Type", "application/json");
        response.getWriter().print(gson.toJson(retorno));
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String body = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
        Gson gson = new Gson();
        Pessoa p = gson.fromJson(body, Pessoa.class);

        int id = 0;
        try {
            id = Integer.parseInt(request.getPathInfo().substring(1));
        } catch (Exception e) {
            e.printStackTrace();
        }
        p.setIdpessoa(id);

        PessoaDao pdao = new PessoaDao();
        boolean sucesso = pdao.alterar(p);
        Retorno retorno = new Retorno(sucesso, sucesso ? "Alterado com sucesso" : "Erro ao alterar");

        response.setHeader("Content-Type", "application/json");
        response.getWriter().print(gson.toJson(retorno));
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = 0;
        try {
            id = Integer.parseInt(request.getPathInfo().substring(1));
        } catch (Exception e) {
            e.printStackTrace();
        }

        Pessoa p = new Pessoa();
        p.setIdpessoa(id);

        PessoaDao pdao = new PessoaDao();
        boolean sucesso = pdao.excluir(p);
        Retorno retorno = new Retorno(sucesso, sucesso ? "Excluído com sucesso" : "Erro ao excluir");

       
        Gson gson = new Gson();
        response.setHeader("Content-Type", "application/json");
        response.getWriter().print(gson.toJson(retorno));
    }

    }

