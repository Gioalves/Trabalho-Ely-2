package org.libertas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class PessoaDao {
    private static LinkedList<Pessoa> lista = new LinkedList<>();

    public void salvar(Pessoa p) {
        if (p.getIdpessoa() > 0) {
            alterar(p);
        } else {
            inserir(p);
        }
    }

    public boolean inserir(Pessoa p) {
        Conexao con = new Conexao();
        String sql = "INSERT INTO pessoa (nome, telefone, email, cidade, endereco, cep) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement prep = con.getConnection().prepareStatement(sql)) {
            prep.setString(1, p.getNome());
            prep.setString(2, p.getTelefone());
            prep.setString(3, p.getEmail());
            prep.setString(4, p.getCidade());
            prep.setString(5, p.getEndereco());
            prep.setString(6, p.getCep());
            return prep.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao inserir: " + e.getMessage());
            return false;
        } finally {
            con.desconecta();
        }
    }

    public boolean alterar(Pessoa p) {
        Conexao con = new Conexao();
        String sql = "UPDATE pessoa SET nome = ?, telefone = ?, email = ?, cidade = ?, endereco = ?, cep = ? WHERE idpessoa = ?";
        try (PreparedStatement prep = con.getConnection().prepareStatement(sql)) {
            prep.setString(1, p.getNome());
            prep.setString(2, p.getTelefone());
            prep.setString(3, p.getEmail());
            prep.setString(4, p.getCidade());
            prep.setString(5, p.getEndereco());
            prep.setString(6, p.getCep());
            prep.setInt(7, p.getIdpessoa());
            return prep.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao alterar: " + e.getMessage());
            return false;
        } finally {
            con.desconecta();
        }
    }

    public boolean excluir(Pessoa p) {
        Conexao con = new Conexao();
        String sql = "DELETE FROM pessoa WHERE idpessoa = ?";
        try (PreparedStatement prep = con.getConnection().prepareStatement(sql)) {
            prep.setInt(1, p.getIdpessoa());
            int rowsAffected = prep.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao excluir: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            con.desconecta();
        }
    }


    public Pessoa consultar(int id) {
        Pessoa p = new Pessoa();
        Conexao con = new Conexao();
        String sql = "SELECT * FROM pessoa WHERE idPessoa = ?";
        try (PreparedStatement prep = con.getConnection().prepareStatement(sql)) {
            prep.setInt(1, id);
            try (ResultSet res = prep.executeQuery()) {
                if (res.next()) {
                    p.setIdpessoa(res.getInt("idpessoa"));
                    p.setNome(res.getString("nome"));
                    p.setTelefone(res.getString("telefone"));
                    p.setEmail(res.getString("email"));
                    p.setCidade(res.getString("cidade"));
                    p.setEndereco(res.getString("endereco"));
                    p.setCep(res.getString("cep"));
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao consultar: " + e.getMessage());
        } finally {
            con.desconecta();
        }
        return p;
    }
    
    public LinkedList<Pessoa> listar() {
		//return lista;
		LinkedList<Pessoa> lista = new LinkedList<Pessoa>();
		Conexao con = new Conexao();
		try {
			String sql = "SELECT * FROM pessoa ORDER BY nome";
			Statement sta = con.getConnection().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				Pessoa p = new Pessoa();
				p.setIdpessoa(res.getInt("idpessoa"));
				p.setNome(res.getString("nome"));
				p.setTelefone(res.getString("telefone"));
				p.setEmail(res.getString("email"));
				p.setCidade(res.getString("cidade"));
				p.setEndereco(res.getString("endereco"));
				p.setCep(res.getString("cep"));
				lista.add(p);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		con.desconecta();
		return lista;
	}

}
